#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdbool.h>
#include <stdint.h>
#include "driver/gpio.h"

// --- SETTING PIN JOYSTICK ---
#define PIN_LEFT  5
#define PIN_RIGHT 6
#define PIN_OK    7
#define WHITE 1
#define BLACK 0

#define BTN_NONE  0
#define BTN_LEFT  1
#define BTN_RIGHT 2
#define BTN_OK    3

// --- STRUKTUR WIFI (String diganti char array) ---
typedef struct {
  int id;
  char ssid[33]; // Max SSID length itu 32 + 1 null terminator
  int rssi;
  int channel;
  char encrypt[20];
  bool is_open;
  char mac[18];
} WiFiData;

typedef struct {
    int id;          // <--- Tambahin ID
    uint8_t mac[6];
    int rssi;
    int paket_count;
} StationInfo;




// Variabel buat Evil Twin
extern bool isEvilTwin;
extern int evilTwinState; 
extern char stolenPassword[64];
extern bool triggerEvilTwin;





// Posisi Bintang (Latar Belakang)
extern int starX[5];
extern int starY[5];

extern bool isWiFiConnected;
extern char connSSID[33];
extern int connRSSI;
extern int connCH;
extern bool triggerDisconnect;
// Update submenu WiFi
extern const char* subMenuWiFi[]; 
extern int statusKoneksi; // 0: Connecting, 1: Berhasil, 2: Gagal

extern char inputPassword[64];
extern int cursorPass; // Posisi karakter yang lagi diedit
extern bool triggerConnect; 
extern bool triggerTrack; // Tambahin ini di deretan extern bool
extern int deauthProgress;
extern bool inSubMenu;
extern int currentMenu;
extern int currentSub;
extern int topMenu;
extern WiFiData listWiFi[30];
extern StationInfo listStation[30];
extern StationInfo targetSta;
extern WiFiData targetTerkunci; 
extern int brightnessValue;
extern int spamState; 
extern bool isSpamming;
extern int aktifModeSpam;
extern bool spamUdahSetup;
extern bool deauthUdahSetup;
extern int scannerState; 
extern int scannerStateSta;  // Udah bener gak pake 'b'
extern uint32_t popUpTimer; 
extern bool triggerScan; 
extern bool triggerScanSta;  // Tambahan
extern bool scanDone;    
extern bool scanStaDone;     // Tambahan
extern int totalWiFi;
extern int totalStation;
extern int cursorInScanner; 
extern int cursorInScanSta;
extern int scrollPosScanner;
extern int targetLockedIdx;
extern int contextCursor;
extern bool adaTarget;  
extern bool adaTargetSta;    // Tambahan
extern int deauthState;
extern bool isDeauthing;
extern bool isDeauthSta;     // Tambahan
extern bool sedang_scan;
extern int appMode;

// --- MISSING EXTERN DECLARATIONS ---
extern int starX[5];
extern int starY[5];

// Carousel animation (used in display + input)
extern int carouselCurrentIdx;
extern int carouselDirection;
extern bool carouselAnimating;
extern uint32_t carouselAnimStart;

// --- FUNCTION PROTOTYPES ---
void start_dns_server(void);

#endif
